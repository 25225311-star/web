# -*- coding: utf-8 -*-
"""日本語Webページをスクレイピングし、形態素解析（Janome）で頻出語を可視化するサンプル。
使い方:
  pip install -r requirements.txt
  python scrape_janome.py "https://www.musashino-u.ac.jp/"
  # => top_words.png と top_words.csv を出力
注意:
  学内や授業ネットワークでは robots.txt や利用規約を守り、過度なアクセスはしないこと。
"""
import sys
import re
import collections
import csv
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup
from janome.tokenizer import Tokenizer
import matplotlib.pyplot as plt

def fetch_text(url: str) -> str:
  headers = {"User-Agent": "Mozilla/5.0 (edu-demo)"}
  r = requests.get(url, headers=headers, timeout=20)
  r.raise_for_status()
  soup = BeautifulSoup(r.text, "html.parser")
  # テキスト抽出（script, styleは除外）
  for s in soup(["script", "style", "noscript"]):
    s.decompose()
  text = soup.get_text(separator=" ")
  text = re.sub(r"\s+", " ", text)
  return text

def tokenize_ja(text: str):
  t = Tokenizer()
  for token in t.tokenize(text):
    base = token.base_form if token.base_form != "*" else token.surface
    part = token.part_of_speech.split(",")[0]
    yield base, part

def count_words(text: str, allowed_pos=("名詞",)):
  counter = collections.Counter()
  for base, pos in tokenize_ja(text):
    if pos in allowed_pos and len(base) >= 2:
      counter[base] += 1
  return counter

def plot_top(counter: collections.Counter, n=20, outfile="top_words.png"):
  words, counts = zip(*counter.most_common(n))
  plt.figure(figsize=(10,6))
  plt.bar(range(len(words)), counts)
  plt.xticks(range(len(words)), words, rotation=60, ha="right")
  plt.tight_layout()
  plt.savefig(outfile)
  print(f"Saved figure: {outfile}")

def save_csv(counter: collections.Counter, n=100, outfile="top_words.csv"):
  with open(outfile, "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["word", "count"])
    for word, cnt in counter.most_common(n):
      w.writerow([word, cnt])
  print(f"Saved CSV: {outfile}")

def main():
  if len(sys.argv) < 2:
    print("Usage: python scrape_janome.py <URL>")
    sys.exit(1)
  url = sys.argv[1]
  print(f"Fetching: {url}")
  text = fetch_text(url)
  print("Tokenizing and counting nouns...")
  counter = count_words(text, allowed_pos=("名詞",))
  if not counter:
    print("No words counted. Check the URL or parsing conditions.")
    sys.exit(0)
  domain = urlparse(url).netloc.replace(".", "_")
  img = f"top_words_{domain}.png"
  csvf = f"top_words_{domain}.csv"
  plot_top(counter, n=20, outfile=img)
  save_csv(counter, n=100, outfile=csvf)

if __name__ == "__main__":
  main()
