# メディアクリエーションII（今週：HTML/CSS/JS とテキストマイニング）配布パック

このパックには以下が含まれます：
- 01_basics/ : HTML/CSS基礎デモ（リンク、画像、テーブル、DIV/SPAN、id/class、色）
- 02_portfolio_starter/ : ポートフォリオサイトのスターター（レスポンシブ、テーマ切替、フォーム）
- 03_js_intro/ : JS導入スクリプト（DOMContentLoaded, DOM操作）
- 04_python_text_hist/ : スクレイピング＋形態素解析（Janome）でヒストグラム作成

## 推奨授業フロー（100分想定）
1. イントロ（10分）: HTML/CSS/JSの役割の違いを確認
2. ライブデモ（25分）: 01_basics を使って、リンク/画像/テーブル/色/ id & class を編集
3. ハンズオン①（20分）: 学生各自、styles.cssの色や余白、フォントを変更して見た目を差別化
4. ライブデモ（15分）: 02_portfolio_starterの構成説明、ナビ/セクション/グリッド/フォーム
5. ハンズオン②（20分）: 自己紹介・作品2件・スキル・連絡フォームを各自で更新
6. まとめ（10分）: 提出方法と評価基準、次回予告（JSとPythonの接続）

## 課題（提出物）
- 02_portfolio_starter をベースにオリジナルのポートフォリオサイトを作成し、以下を満たす：
  - 最低4ページ（または1ページ内で4セクション）
  - 画像2点以上、外部リンク1つ以上、テーブルまたはリスト1箇所以上
  - `id` と `class` を適切に使い分け、CSSで最低5箇所をカスタム
  - レスポンシブ対応（幅600pxと1200pxで崩れない）
  - README.mdに工夫点を箇条書き

## 評価ルーブリック（各20点・合計100点）
- 構造: HTMLの文書構造・セマンティクスの適切さ
- 視覚: CSSレイアウト・色・余白・タイポグラフィの一貫性
- コード品質: 冗長さ回避、命名、再利用性（class活用）
- アクセシビリティ: alt / label / 対比比 / キーボード操作配慮
- プレゼン: READMEの明瞭さ、サイトの完成度・独自性

## JS導入メモ
- `<script src="script.js" defer></script>` でHTMLパース後に実行
- DOM操作: `document.querySelector`, `classList.toggle`, `addEventListener`
- 短いインタラクション（テーマ切替、フォーム送信メッセージ）から始める

## Pythonテキスト分析メモ
- 事前: `pip install -r requirements.txt`
- 使い方: `python scrape_janome.py <URL>`
- 出力: `top_words_*.png`（頻出名詞の棒グラフ）と `top_words_*.csv`
- 注意: robots.txtと利用規約を遵守。過度なリクエスト禁止。

